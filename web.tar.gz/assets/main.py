import asyncio
import random
import pygame

pygame.init()
pygame.font.init()

SCREEN_WIDTH = 800
SCREEN_HEIGHT = 400
FPS = 60

# Colors (RGB)
BG_COLOR = (235, 230, 215)      # paper color, like the drawings
FLOOR_COLOR = (50, 180, 80)
TITLE_COLOR = (215, 30, 40)     # red, like the hero
TEXT_COLOR = (30, 30, 40)
INK_COLOR = (15, 15, 20)        # black pen, like the drawings
WALL_COLOR = (90, 90, 100)      # inside of the barriers

screen = pygame.display.set_mode((SCREEN_WIDTH, SCREEN_HEIGHT))
pygame.display.set_caption("My First Geometry Runner")
pygame.display.set_icon(pygame.image.load("assets/game-icon.png"))   # our drawing in the Dock (made by tools/make_icon.py)
clock = pygame.time.Clock()

# Pictures drawn by hand (made from the drawings by tools/make_sprites.py)
HERO_IMAGE = pygame.image.load("assets/square-hero-sprite.png").convert_alpha()
SPIKE_IMAGE = pygame.image.load("assets/spike-sprite.png").convert_alpha()
TROPHY_IMAGE = pygame.image.load("assets/trophy-sprite.png").convert_alpha()
ORB_IMAGE = pygame.image.load("assets/orb-sprite.png").convert_alpha()
WIN_IMAGE = pygame.image.load("assets/level-complete-sprite.png").convert_alpha()
BACKGROUND_IMAGE = pygame.image.load("assets/background-tile.png").convert_alpha()

# Background settings (the marker-lines drawing behind every level, made by tools/make_background.py)
BACKGROUND_STRENGTH = 120       # how strong the lines look: 0 = invisible, 255 = full color
BACKGROUND_SCROLL = 0.5         # how fast it moves compared to the obstacles (smaller = looks farther away)

# Fonts for UI text
font_title = pygame.font.SysFont("Arial", 44, bold=True)
font_instruction = pygame.font.SysFont("Arial", 22)

FLOOR_Y = 320

# Player settings
player_size = 50
HERO_PICTURE_HEIGHT = 100  # the drawing is bigger than the player: spikes stick out around the red box
player_x = 100
player_y = FLOOR_Y - player_size

velocity_y = 0
GRAVITY = 0.8
JUMP_STRENGTH = -14
is_grounded = True
angle = 0

# Speed settings (how many pixels the world moves every frame)
SPEED = 6                       # normal speed
FAST_SPEED = 8                  # after a "777" portal
SLOW_SPEED = 4                  # after a "7" portal
speed = SPEED

# Jump pad settings (a yellow bump on the ground that throws the hero up high)
PAD_STRENGTH = -18              # stronger than a normal jump (JUMP_STRENGTH)
PAD_HEIGHT = 12
PAD_COLOR = (245, 220, 40)

# Portal settings (tall ovals; the "777" one makes the game fast, the "7" one slow)
PORTAL_WIDTH = 36
PORTAL_HEIGHT = 120
PORTAL_SPEEDS = {"portal_fast": FAST_SPEED, "portal_slow": SLOW_SPEED}
PORTAL_LABELS = {"portal_fast": "777", "portal_slow": "7", "ring": ""}
PORTAL_COLORS = {"portal_fast": (230, 120, 20), "portal_slow": (40, 110, 220), "ring": INK_COLOR}

# Level settings
LEVEL_SECONDS = 30              # how long a random run lasts (in seconds)
QUIET_END_SECONDS = 3           # no new obstacles at the very end, so the way to the finish is clear
TROPHY_HEIGHT = 90             # the trophy waits at the finish (official levels only)
TROPHY_GAP = 30                 # space between the hero and the trophy at the end, so the spikes don't cover it
WIN_PICTURE_HEIGHT = 320        # size of the "Level complete" drawing on the winning screen
WIN_PICTURE_TOP = 15            # how far from the top of the window it starts
level_mode = "RANDOM"           # "RANDOM" (made up while you play) or "LEVEL_1" (the drawn level)
level_length = LEVEL_SECONDS * FPS * SPEED   # how far it is to the trophy (in pixels)
distance = 0                    # how far the hero has come

# Obstacle settings
SPIKE_WIDTH = 40
SPIKE_HEIGHT = 50
DOWN_SPIKE_HEIGHT = 30          # spikes hanging down under a hanging block
LOW_WALL_WIDTH = 90             # a long, flat barrier
LOW_WALL_HEIGHT = 40
TALL_WALL_WIDTH = 40            # a thin, tall barrier
TALL_WALL_HEIGHT = 65
SPAWN_MIN_FRAMES = 60           # shortest wait before the next obstacle group
SPAWN_MAX_FRAMES = 110          # longest wait before the next obstacle group
BLOCK_KINDS = ["block", "hanging", "low_wall", "tall_wall"]   # you can stand on these
HARMLESS_KINDS = ["pad", "portal_fast", "portal_slow", "ring"]  # touching these doesn't crash

# Groups of obstacles the random run picks from.
# Each piece: (what it is, how far to the right of the group's start)
OBSTACLE_PATTERNS = [
    [("spike", 0)],
    [("spike", 0), ("spike", SPIKE_WIDTH)],
    [("low_wall", 0)],
    [("tall_wall", 0)],
]
OBSTACLE_SIZES = {
    "spike": (SPIKE_WIDTH, SPIKE_HEIGHT),
    "low_wall": (LOW_WALL_WIDTH, LOW_WALL_HEIGHT),
    "tall_wall": (TALL_WALL_WIDTH, TALL_WALL_HEIGHT),
}

# LEVEL 1, copied from the drawing assets/level-1.jpg (6 rows, read left to right, top to bottom).
# Each thing: (what, where it starts, how wide, how high)
#   where  - pixels from the start of the level
#   how high - for "block": its height. For "hanging": how high the tips of its spikes are.
#              For everything else: how high it sits (0 = on the floor, 100 = on top of a 100-high block)
LEVEL_1 = [
    # Row 1: the bridge
    ("spikes", 700, 40, 0),             # one spike
    ("block", 1000, 40, 40),            # spikes between two little blocks (land on the first one, then jump again!)
    ("spikes", 1040, 80, 0),
    ("block", 1120, 40, 40),
    ("hanging", 1500, 200, 70),         # a block hanging from the sky: walk under, don't jump!
    ("spikes", 2200, 80, 0),            # 2 spikes under an arch

    # Row 2: the oval, then jump pads over rows of spikes
    ("ring", 2700, 36, 0),              # the oval (what does it do? nothing yet)
    ("pad", 2900, 40, 0), ("spikes", 2970, 120, 0),
    ("pad", 3164, 40, 0), ("spikes", 3234, 120, 0),
    ("pad", 3428, 40, 0), ("spikes", 3498, 120, 0),
    ("pad", 3692, 40, 0),
    ("pad", 4250, 40, 0), ("spikes", 4320, 120, 0),
    ("pad", 4514, 40, 0), ("spikes", 4584, 120, 0),
    ("pad", 4778, 40, 0),

    # Row 3: a pad up onto a long high path, then a pad over a spike row
    ("pad", 5250, 40, 0),
    ("block", 5370, 1130, 100),         # the long high path
    ("spikes", 5800, 40, 100),          # spikes on top of the path
    ("spikes", 6150, 80, 100),
    ("pad", 6700, 40, 0), ("spikes", 6770, 120, 0),
    ("spikes", 7200, 80, 0),            # tall spikes at the end of the row

    # Row 4: "777" makes everything fast, then a long empty run
    ("pad", 7500, 40, 0),
    ("portal_fast", 7620, 36, 0),

    # Row 5: "7" makes everything slow, then 8 jumps from pad to pad
    ("portal_slow", 9300, 36, 0),
    ("pad", 9500, 40, 0), ("spikes", 9560, 40, 0),
    ("pad", 9676, 40, 0), ("spikes", 9736, 40, 0),
    ("pad", 9852, 40, 0), ("spikes", 9912, 40, 0),
    ("pad", 10028, 40, 0), ("spikes", 10088, 40, 0),
    ("pad", 10204, 40, 0), ("spikes", 10264, 40, 0),
    ("pad", 10380, 40, 0), ("spikes", 10440, 40, 0),
    ("pad", 10556, 40, 0), ("spikes", 10616, 40, 0),
    ("pad", 10732, 40, 0),

    # Row 6: HOLD to keep jumping on a high path, drop down, jump the last spikes
    ("pad", 11100, 40, 0),
    ("block", 11180, 1220, 80),
    ("spikes", 11500, 40, 80),
    ("spikes", 11800, 40, 80),
    ("spikes", 12100, 40, 80),
    ("spikes", 12650, 40, 0),           # down at the bottom
    ("spikes", 12900, 40, 0),
    ("spikes", 13150, 40, 0),
]
LEVEL_1_LENGTH = 13500          # where the trophy (END) stands

# Autopilot settings (the computer plays by itself; press A to switch it on or off)
AUTO_LEVELS = ["LEVEL_1"]       # where the autopilot works (add "RANDOM" to use it in the random run too)
AUTO_PLAY = True                # True = the autopilot is on when the game starts (press A to switch it off)
AUTO_JUMP_FRAMES = 1            # extra frames the autopilot jumps early (0-2 work, 3+ jumps too early and crashes)
DANGER_KINDS = ["spike", "low_wall", "tall_wall", "block"]   # things the autopilot jumps over
AUTO_THINK_FRAMES = 90          # how far into the future the autopilot imagines (60 frames = 1 second)
AUTO_COLOR = (40, 110, 220)     # color of the "AUTOPILOT" sign
auto_play = AUTO_PLAY

obstacles = []                  # each one: (what it is, its box on the screen)
spawn_timer = 0
next_spawn = SPAWN_MIN_FRAMES

# Orb settings (orbs are money for the shop)
ORB_CHANCE = 0.6                # how often an orb floats above an obstacle group (0 = never, 1 = always)
ORB_HEIGHT = 30                 # orb picture height
ORB_ABOVE_FLOOR = 140           # how high the orb floats, so you catch it by jumping
orbs = []                       # boxes of the orbs on the screen
orbs_collected = 0

# Make the pictures the right size for the game
hero_picture = pygame.transform.smoothscale_by(HERO_IMAGE, HERO_PICTURE_HEIGHT / HERO_IMAGE.get_height())
spike_picture = pygame.transform.smoothscale(SPIKE_IMAGE, (SPIKE_WIDTH, SPIKE_HEIGHT))
down_spike_picture = pygame.transform.flip(
    pygame.transform.smoothscale(SPIKE_IMAGE, (SPIKE_WIDTH, DOWN_SPIKE_HEIGHT)), False, True)
trophy_picture = pygame.transform.smoothscale_by(TROPHY_IMAGE, TROPHY_HEIGHT / TROPHY_IMAGE.get_height())
orb_picture = pygame.transform.smoothscale_by(ORB_IMAGE, ORB_HEIGHT / ORB_IMAGE.get_height())
win_picture = pygame.transform.smoothscale_by(WIN_IMAGE, WIN_PICTURE_HEIGHT / WIN_IMAGE.get_height())

# The background picture: paper color with soft marker lines on top
background_picture = pygame.Surface(BACKGROUND_IMAGE.get_size())
background_picture.fill(BG_COLOR)
BACKGROUND_IMAGE.set_alpha(BACKGROUND_STRENGTH)
background_picture.blit(BACKGROUND_IMAGE, (0, 0))

# Game States: "MENU", "PLAYING" or "WON"
game_state = "MENU"

def build_level(level):
    # Turn the level list into boxes on the screen (most of them still far to the right)
    built = []
    for kind, start, width, high in level:
        x = player_x + start
        bottom = FLOOR_Y - high           # where its bottom sits
        if kind == "spikes":
            for spike_x in range(x, x + width, SPIKE_WIDTH):
                built.append(("spike", pygame.Rect(spike_x, bottom - SPIKE_HEIGHT, SPIKE_WIDTH, SPIKE_HEIGHT)))
        elif kind == "block":
            built.append(("block", pygame.Rect(x, bottom, width, high)))
        elif kind == "hanging":
            # a block from the top of the window down, with spikes pointing down under it
            built.append(("hanging", pygame.Rect(x, 0, width, bottom - DOWN_SPIKE_HEIGHT)))
            for spike_x in range(x, x + width, SPIKE_WIDTH):
                built.append(("spike_down", pygame.Rect(spike_x, bottom - DOWN_SPIKE_HEIGHT, SPIKE_WIDTH, DOWN_SPIKE_HEIGHT)))
        elif kind == "pad":
            built.append(("pad", pygame.Rect(x, bottom - PAD_HEIGHT, width, PAD_HEIGHT)))
        else:  # portals and the ring
            built.append((kind, pygame.Rect(x, bottom - PORTAL_HEIGHT, width, PORTAL_HEIGHT)))
    return built

def reset_game(mode):
    global player_y, velocity_y, is_grounded, angle, obstacles, spawn_timer, next_spawn
    global orbs, orbs_collected, level_mode, level_length, distance, speed
    player_y = FLOOR_Y - player_size
    velocity_y = 0
    is_grounded = True
    angle = 0
    orbs = []
    orbs_collected = 0
    spawn_timer = 0
    next_spawn = SPAWN_MIN_FRAMES
    distance = 0
    speed = SPEED
    level_mode = mode
    if mode == "LEVEL_1":
        obstacles = build_level(LEVEL_1)
        level_length = LEVEL_1_LENGTH
    else:
        obstacles = []
        level_length = LEVEL_SECONDS * FPS * SPEED

def add_obstacle_group():
    # Pick a random group and put it just past the right edge of the screen
    group_right = SCREEN_WIDTH
    for kind, offset in random.choice(OBSTACLE_PATTERNS):
        width, height = OBSTACLE_SIZES[kind]
        box = pygame.Rect(SCREEN_WIDTH + offset, FLOOR_Y - height, width, height)
        obstacles.append((kind, box))
        group_right = max(group_right, box.right)

    # Sometimes an orb floats above the group, to grab while jumping over it
    if random.random() < ORB_CHANCE:
        orb_box = orb_picture.get_rect(center=((SCREEN_WIDTH + group_right) // 2, FLOOR_Y - ORB_ABOVE_FLOOR))
        orbs.append(orb_box)

def frames_to_climb(height):
    # How many frames a jump needs to lift the hero's feet this high
    climbed = 0
    jump_speed = JUMP_STRENGTH
    frames = 0
    while climbed < height and jump_speed < 0:
        jump_speed += GRAVITY
        climbed -= jump_speed
        frames += 1
    return frames

def danger_is_close():
    # The autopilot's simple rule: look for the next danger: something sticking up higher than the hero's feet
    feet = player_y + player_size
    dangers = sorted((box for kind, box in obstacles
                      if kind in DANGER_KINDS and box.right > player_x and box.top < feet),
                     key=lambda box: box.left)
    if not dangers:
        return False

    # Dangers right next to each other are one big danger: aim for the tallest one
    target = dangers[0]
    group_right = target.right
    for box in dangers[1:]:
        if box.left > group_right + player_size:
            break  # the hero fits in this gap, so the next danger comes later
        group_right = max(group_right, box.right)
        if box.top < target.top:
            target = box

    # A jump pad comes first? Then let the pad throw the hero over
    for kind, box in obstacles:
        if kind == "pad" and box.right > player_x and box.left < target.left:
            return False

    # Jump just in time: when the hero would need exactly this long to climb over it
    gap = target.left - (player_x + player_size)
    return gap <= speed * (frames_to_climb(feet - target.top) + AUTO_JUMP_FRAMES)

def remember_game():
    # Take a "photo" of everything that moves, so we can put it back later
    return (game_state, player_y, velocity_y, is_grounded, angle, distance, speed,
            [(kind, box.copy()) for kind, box in obstacles], spawn_timer, next_spawn,
            [orb_box.copy() for orb_box in orbs], orbs_collected, random.getstate())

def put_game_back(photo):
    # Put everything back exactly like in the "photo"
    global game_state, player_y, velocity_y, is_grounded, angle, distance, speed
    global obstacles, spawn_timer, next_spawn, orbs, orbs_collected
    (game_state, player_y, velocity_y, is_grounded, angle, distance, speed,
     obstacles, spawn_timer, next_spawn, orbs, orbs_collected, random_state) = photo
    obstacles = [(kind, box.copy()) for kind, box in obstacles]
    orbs = [orb_box.copy() for orb_box in orbs]
    random.setstate(random_state)

def can_survive(frames_left, dead_ends):
    # Play on "in the head": is there ANY way to jump that keeps the hero alive this long?
    # It tries the simple rule first, and the opposite only if the simple rule crashes.
    if game_state != "PLAYING" or frames_left == 0:
        return game_state != "MENU"   # "MENU" means it crashed
    if not is_grounded:
        update_game(False)            # in the air there is nothing to decide
        return can_survive(frames_left - 1, dead_ends)

    spot = (distance, round(player_y), round(velocity_y))
    if spot in dead_ends:
        return False                  # we already know: from here, every way crashes
    usual = danger_is_close()
    photo = remember_game()
    for jump in (usual, not usual):
        update_game(jump)
        if can_survive(frames_left - 1, dead_ends):
            return True
        put_game_back(photo)
    dead_ends.add(spot)
    return False

def autopilot_wants_jump():
    # Should the autopilot press jump right now? It imagines the future before deciding.
    if game_state != "PLAYING" or not is_grounded:
        return False                  # it can only jump when standing on something
    usual = danger_is_close()
    photo = remember_game()
    dead_ends = set()
    for jump in (usual, not usual):
        update_game(jump)
        survived = can_survive(AUTO_THINK_FRAMES, dead_ends)
        put_game_back(photo)
        if survived:
            return jump               # this way works (maybe it's a stepping-stone jump!)
    return usual                      # every way crashes: just do the usual thing

def update_game(holding):
    # One step of the game (60 times a second). holding = Space or a finger is down.
    global game_state, player_y, velocity_y, is_grounded, angle, distance, speed
    global obstacles, spawn_timer, next_spawn, orbs, orbs_collected

    # Jump while Space or a finger is held down: keep holding and the hero jumps again every time it lands
    if game_state == "PLAYING" and holding and is_grounded:
        velocity_y = JUMP_STRENGTH
        is_grounded = False

    # Gravity keeps working after winning, so the hero lands at the finish
    if game_state == "PLAYING" or game_state == "WON":
        velocity_y += GRAVITY
        player_y += velocity_y

        if player_y >= FLOOR_Y - player_size:
            player_y = FLOOR_Y - player_size
            velocity_y = 0
            is_grounded = True
            angle = round(angle / 90) * 90
        else:
            is_grounded = False  # in the air (a block below can still catch the hero, see below)

        if not is_grounded:
            angle += 8

    # Only scroll, spawn and check crashes while actively playing
    if game_state != "PLAYING":
        return

    # Move forward; at the end of the level, the hero has won!
    distance += speed
    if distance >= level_length:
        distance = level_length
        game_state = "WON"

    # Random run: a new random group of obstacles now and then (but not right before the finish)
    if level_mode == "RANDOM":
        spawn_timer += 1
        if spawn_timer >= next_spawn and level_length - distance > QUIET_END_SECONDS * FPS * speed:
            add_obstacle_group()
            spawn_timer = 0
            next_spawn = random.randint(SPAWN_MIN_FRAMES, SPAWN_MAX_FRAMES)

    # Move obstacles to the left, forget the ones that left the screen
    for kind, box in obstacles:
        box.x -= speed
    obstacles = [(kind, box) for kind, box in obstacles if box.right > 0]
    for orb_box in orbs:
        orb_box.x -= speed

    # Land on top of blocks: if the hero was above the block's top a moment ago
    # and is falling onto it now, it stands on the block instead of crashing
    for kind, box in obstacles:
        if kind not in BLOCK_KINDS:
            continue  # you can never stand on a spike!
        bottom = player_y + player_size
        bottom_before = bottom - velocity_y
        above_block = player_x + player_size > box.left and player_x < box.right
        if above_block and velocity_y >= 0 and bottom_before <= box.top <= bottom:
            player_y = box.top - player_size
            velocity_y = 0
            is_grounded = True
            angle = round(angle / 90) * 90

    player_rect = pygame.Rect(player_x, player_y, player_size, player_size)
    for kind, box in obstacles:
        # Jump pads throw the hero up high
        if kind == "pad" and player_rect.colliderect(box) and velocity_y >= 0:
            velocity_y = PAD_STRENGTH
            is_grounded = False
        # Portals change the speed when the hero goes through them
        if kind in PORTAL_SPEEDS and box.left < player_rect.right and box.right > player_rect.left:
            speed = PORTAL_SPEEDS[kind]

    # Grab orbs the hero touches, forget the ones that left the screen
    for orb_box in orbs:
        if player_rect.colliderect(orb_box):
            orbs_collected += 1
    orbs = [orb_box for orb_box in orbs if not player_rect.colliderect(orb_box) and orb_box.right > 0]

    # Collision Check -> Send player back to menu on crash
    # (touching a spike, or running into the side of a block)
    for kind, box in obstacles:
        if kind not in HARMLESS_KINDS and player_rect.colliderect(box):
            game_state = "MENU"  # Return to menu on crash

async def main():
    # The game loop lives in main() so it can also run in a web browser
    global game_state, auto_play

    running = True
    while running:
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                running = False

            # A = switch the autopilot on or off (works in the menu and while playing)
            if event.type == pygame.KEYDOWN and event.key == pygame.K_a:
                auto_play = not auto_play

            # Keyboard: Space/Enter = random run, 1 = Level 1.
            # Tap or click: left half of the screen = random run, right half = Level 1.
            pick = None
            if event.type == pygame.KEYDOWN and event.key in (pygame.K_SPACE, pygame.K_RETURN):
                pick = "RANDOM"
            if event.type == pygame.KEYDOWN and event.key in (pygame.K_1, pygame.K_KP1):
                pick = "LEVEL_1"
            if event.type == pygame.MOUSEBUTTONDOWN:
                pick = "RANDOM" if event.pos[0] < SCREEN_WIDTH // 2 else "LEVEL_1"
            if pick:
                if game_state == "MENU":
                    # Start the game from the menu
                    game_state = "PLAYING"
                    reset_game(pick)

                elif game_state == "WON":
                    # Go back to the menu
                    game_state = "MENU"

        # Update: everything moves one step
        holding = pygame.key.get_pressed()[pygame.K_SPACE] or pygame.mouse.get_pressed()[0]
        if auto_play and level_mode in AUTO_LEVELS and autopilot_wants_jump():
            holding = True    # the autopilot "presses Space" for you
        update_game(holding)

        # --- DRAWING SECTION ---
        screen.fill(BG_COLOR)

        if game_state == "MENU":
            # Draw Start Menu UI: random run on the left, Level 1 on the right
            title_surf = font_title.render("GEOMETRY RUNNER", True, TITLE_COLOR)
            screen.blit(title_surf, (SCREEN_WIDTH // 2 - title_surf.get_width() // 2, 110))
            pygame.draw.line(screen, INK_COLOR, (SCREEN_WIDTH // 2, 190), (SCREEN_WIDTH // 2, 300), 2)
            choices = [("Random run", "SPACE or tap here", SCREEN_WIDTH // 4),
                       ("Level 1", "press 1 or tap here", SCREEN_WIDTH * 3 // 4)]
            for name, how, center_x in choices:
                name_surf = font_title.render(name, True, TEXT_COLOR)
                how_surf = font_instruction.render(how, True, TEXT_COLOR)
                screen.blit(name_surf, (center_x - name_surf.get_width() // 2, 200))
                screen.blit(how_surf, (center_x - how_surf.get_width() // 2, 260))
            # The autopilot switch sits under Level 1, because it only works there
            auto_text = "Autopilot: ON (press A)" if auto_play else "Autopilot: OFF (press A)"
            auto_surf = font_instruction.render(auto_text, True, AUTO_COLOR)
            screen.blit(auto_surf, (SCREEN_WIDTH * 3 // 4 - auto_surf.get_width() // 2, 300))

        elif game_state == "WON":
            # The winning screen: the "Level complete" drawing in the middle
            screen.blit(win_picture, (SCREEN_WIDTH // 2 - win_picture.get_width() // 2, WIN_PICTURE_TOP))
            again_surf = font_instruction.render("Press SPACE or tap the screen for the menu", True, TEXT_COLOR)
            again_y = WIN_PICTURE_TOP + win_picture.get_height() + 12
            screen.blit(again_surf, (SCREEN_WIDTH // 2 - again_surf.get_width() // 2, again_y))

        elif game_state == "PLAYING":
            # Draw the background: copies side by side, sliding left slower than the obstacles
            background_width = background_picture.get_width()
            background_x = -int(distance * BACKGROUND_SCROLL) % background_width
            for x in range(background_x - background_width, SCREEN_WIDTH, background_width):
                screen.blit(background_picture, (x, 0))

            # Draw Obstacles (spikes, blocks, pads, portals) that are on the screen
            for kind, box in obstacles:
                if box.left > SCREEN_WIDTH:
                    continue
                if kind == "spike":
                    screen.blit(spike_picture, box.topleft)
                elif kind == "spike_down":
                    screen.blit(down_spike_picture, box.topleft)
                elif kind == "pad":
                    # a yellow bump: the top half of an oval
                    screen.set_clip(box)
                    pygame.draw.ellipse(screen, PAD_COLOR, (box.x, box.y, box.width, box.height * 2))
                    pygame.draw.ellipse(screen, INK_COLOR, (box.x, box.y, box.width, box.height * 2), 3)
                    screen.set_clip(None)
                elif kind in PORTAL_COLORS:
                    pygame.draw.ellipse(screen, PORTAL_COLORS[kind], box, 6)
                    label_surf = font_instruction.render(PORTAL_LABELS[kind], True, PORTAL_COLORS[kind])
                    screen.blit(label_surf, (box.centerx - label_surf.get_width() // 2, box.top - 28))
                else:
                    pygame.draw.rect(screen, WALL_COLOR, box)
                    pygame.draw.rect(screen, INK_COLOR, box, 3)

            # Draw Floor
            pygame.draw.rect(screen, FLOOR_COLOR, (0, FLOOR_Y, SCREEN_WIDTH, SCREEN_HEIGHT - FLOOR_Y))

            # Draw Orbs
            for orb_box in orbs:
                screen.blit(orb_picture, orb_box.topleft)

            # Draw the trophy at the finish: it scrolls in and stops right in front of the hero
            finish_x = player_x + player_size + TROPHY_GAP + (level_length - distance)
            if finish_x < SCREEN_WIDTH:
                screen.blit(trophy_picture, (finish_x, FLOOR_Y - TROPHY_HEIGHT))

            # Draw the orb counter in the top left corner
            screen.blit(orb_picture, (16, 12))
            orbs_surf = font_instruction.render(str(orbs_collected), True, TEXT_COLOR)
            screen.blit(orbs_surf, (16 + orb_picture.get_width() + 8, 14))

            # Top right corner: the countdown (random run) or how far you got (Level 1)
            if level_mode == "RANDOM":
                frames_left = (level_length - distance) // speed
                seconds_left = (frames_left + FPS - 1) // FPS
                corner_text = f"{seconds_left // 60}:{seconds_left % 60:02d}"
            else:
                corner_text = f"Level 1   {distance * 100 // level_length}%"
            corner_surf = font_instruction.render(corner_text, True, TEXT_COLOR)
            screen.blit(corner_surf, (SCREEN_WIDTH - corner_surf.get_width() - 16, 12))

            # A sign at the top in the middle while the computer is playing
            if auto_play and level_mode in AUTO_LEVELS:
                auto_surf = font_instruction.render("AUTOPILOT", True, AUTO_COLOR)
                screen.blit(auto_surf, (SCREEN_WIDTH // 2 - auto_surf.get_width() // 2, 12))

            # Draw Player
            rotated_surface = pygame.transform.rotate(hero_picture, -angle)
            new_rect = rotated_surface.get_rect(center=(player_x + player_size // 2, player_y + player_size // 2))
            screen.blit(rotated_surface, new_rect.topleft)

        pygame.display.flip()
        clock.tick(FPS)
        await asyncio.sleep(0)  # let the browser update the page (does nothing on the computer)

    pygame.quit()

asyncio.run(main())
