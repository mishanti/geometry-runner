import asyncio
import random
import pygame

pygame.init()
pygame.font.init()

SCREEN_WIDTH = 800
SCREEN_HEIGHT = 400
FPS = 60

# Colors (RGB)
BG_COLOR = (235, 230, 215)      # paper color, like the drawings
FLOOR_COLOR = (50, 180, 80)
TITLE_COLOR = (215, 30, 40)     # red, like the hero
TEXT_COLOR = (30, 30, 40)
INK_COLOR = (15, 15, 20)        # black pen, like the drawings
WALL_COLOR = (90, 90, 100)      # inside of the barriers

screen = pygame.display.set_mode((SCREEN_WIDTH, SCREEN_HEIGHT))
pygame.display.set_caption("My First Geometry Runner")
pygame.display.set_icon(pygame.image.load("assets/game-icon.png"))   # our drawing in the Dock (made by tools/make_icon.py)
clock = pygame.time.Clock()

# Pictures drawn by hand (made from the drawings by tools/make_sprites.py)
HERO_IMAGE = pygame.image.load("assets/square-hero-sprite.png").convert_alpha()
SPIKE_IMAGE = pygame.image.load("assets/spike-sprite.png").convert_alpha()
TROPHY_IMAGE = pygame.image.load("assets/trophy-sprite.png").convert_alpha()
ORB_IMAGE = pygame.image.load("assets/orb-sprite.png").convert_alpha()
WIN_IMAGE = pygame.image.load("assets/level-complete-sprite.png").convert_alpha()
BACKGROUND_IMAGE = pygame.image.load("assets/background-tile.png").convert_alpha()
START_IMAGE = pygame.image.load("assets/start-screen-sprite.png").convert_alpha()

# Title screen settings (the first screen: the artist's drawing with a PLAY button)
START_PICTURE_X = (SCREEN_WIDTH - START_IMAGE.get_width()) // 2   # the drawing sits in the middle
PLAY_BUTTON = pygame.Rect(START_PICTURE_X + 169, 100, 90, 110)    # where "PLAY" is in the drawing
PLAY_BLINK_FRAMES = 30          # the PLAY button's frame blinks on and off this often (0 = no frame)
PLAY_FRAME_COLOR = (245, 200, 30)

# Background settings (the marker-lines drawing behind every level, made by tools/make_background.py)
BACKGROUND_STRENGTH = 120       # how strong the lines look: 0 = invisible, 255 = full color
BACKGROUND_SCROLL = 0.5         # how fast it moves compared to the obstacles (smaller = looks farther away)

# Fonts for UI text
font_title = pygame.font.SysFont("Arial", 44, bold=True)
font_instruction = pygame.font.SysFont("Arial", 22)

FLOOR_Y = 320

# Player settings
player_size = 50
HERO_PICTURE_HEIGHT = 100  # the drawing is bigger than the player: spikes stick out around the red box
player_x = 100
player_y = FLOOR_Y - player_size

velocity_y = 0
GRAVITY = 0.8
JUMP_STRENGTH = -14
is_grounded = True
angle = 0

# Speed settings (how many pixels the world moves every frame)
SPEED = 6                       # normal speed
FAST_SPEED = 8                  # after a "777" portal
SLOW_SPEED = 4                  # after a "7" portal
speed = SPEED

# Jump pad settings (a yellow bump on the ground that throws the hero up high)
PAD_STRENGTH = -18              # stronger than a normal jump (JUMP_STRENGTH)
PAD_HEIGHT = 12
PAD_COLOR = (245, 220, 40)

# Portal settings (tall ovals; the "777" one makes the game fast, the "7" one slow)
PORTAL_WIDTH = 36
PORTAL_HEIGHT = 120
PORTAL_SPEEDS = {"portal_fast": FAST_SPEED, "portal_slow": SLOW_SPEED}
PORTAL_LABELS = {"portal_fast": "777", "portal_slow": "7", "ring": "",
                 "portal_fly": "FLY", "portal_run": "RUN"}
PORTAL_COLORS = {"portal_fast": (230, 120, 20), "portal_slow": (40, 110, 220), "ring": INK_COLOR,
                 "portal_fly": (220, 50, 170), "portal_run": (40, 160, 70)}

# Flying settings (after a pink "FLY" portal: hold to go up, let go to sink; a green "RUN" portal ends it)
FLY_LIFT = 0.5                  # how fast holding pushes the hero up
FLY_GRAVITY = 0.5               # how fast it sinks when you let go
FLY_MAX_SPEED = 6               # it never goes up or down faster than this
FLY_TILT = 4                    # how much the hero tilts while flying up or down
flying = False

# Jump orb settings (yellow rings in the air: press jump while touching one to jump again. Not money!)
JUMP_ORB_SIZE = 50
JUMP_ORB_COLOR = (245, 200, 30)

# More things to build levels with
SQUARE_HEIGHT = 40              # a floating square block (stand on it, don't bump into it)
PIT_COLOR = (60, 45, 40)        # a hole in the ground
PIT_FALL_DEPTH = 20             # how far the hero can sink into a pit before it's lost
FENCE_GAP = 20                  # space between the bars of a fence

# Level settings
LEVEL_SECONDS = 30              # how long a random run lasts (in seconds)
QUIET_END_SECONDS = 3           # no new obstacles at the very end, so the way to the finish is clear
TROPHY_HEIGHT = 90             # the trophy waits at the finish (official levels only)
TROPHY_GAP = 30                 # space between the hero and the trophy at the end, so the spikes don't cover it
WIN_PICTURE_HEIGHT = 320        # size of the "Level complete" drawing on the winning screen
WIN_PICTURE_TOP = 15            # how far from the top of the window it starts
level_mode = "RANDOM"           # "RANDOM" (made up while you play), "LEVEL_1" or "LEVEL_2" (drawn levels)
level_length = LEVEL_SECONDS * FPS * SPEED   # how far it is to the trophy (in pixels)
distance = 0                    # how far the hero has come

# Obstacle settings
SPIKE_WIDTH = 40
SPIKE_HEIGHT = 50
DOWN_SPIKE_HEIGHT = 30          # spikes hanging down under a hanging block
LOW_WALL_WIDTH = 90             # a long, flat barrier
LOW_WALL_HEIGHT = 40
TALL_WALL_WIDTH = 40            # a thin, tall barrier
TALL_WALL_HEIGHT = 65
SPAWN_MIN_FRAMES = 60           # shortest wait before the next obstacle group
SPAWN_MAX_FRAMES = 110          # longest wait before the next obstacle group
BLOCK_KINDS = ["block", "hanging", "low_wall", "tall_wall", "square", "fence"]   # you can stand on these
HARMLESS_KINDS = ["pad", "portal_fast", "portal_slow", "ring", "portal_fly", "portal_run",
                  "jump_orb", "used_orb", "pit"]   # touching these doesn't crash

# Groups of obstacles the random run picks from.
# Each piece: (what it is, how far to the right of the group's start)
OBSTACLE_PATTERNS = [
    [("spike", 0)],
    [("spike", 0), ("spike", SPIKE_WIDTH)],
    [("low_wall", 0)],
    [("tall_wall", 0)],
]
OBSTACLE_SIZES = {
    "spike": (SPIKE_WIDTH, SPIKE_HEIGHT),
    "low_wall": (LOW_WALL_WIDTH, LOW_WALL_HEIGHT),
    "tall_wall": (TALL_WALL_WIDTH, TALL_WALL_HEIGHT),
}

# LEVEL 1, copied from the drawing assets/level-1.jpg (6 rows, read left to right, top to bottom).
# Each thing: (what, where it starts, how wide, how high)
#   where  - pixels from the start of the level
#   how high - for "block": its height. For "hanging": how high the tips of its spikes are.
#              For everything else: how high it sits (0 = on the floor, 100 = on top of a 100-high block)
LEVEL_1 = [
    # Row 1: the bridge
    ("spikes", 700, 40, 0),             # one spike
    ("block", 1000, 40, 40),            # spikes between two little blocks (land on the first one, then jump again!)
    ("spikes", 1040, 80, 0),
    ("block", 1120, 40, 40),
    ("hanging", 1500, 200, 70),         # a block hanging from the sky: walk under, don't jump!
    ("spikes", 2200, 80, 0),            # 2 spikes under an arch

    # Row 2: the oval, then jump pads over rows of spikes
    ("ring", 2700, 36, 0),              # the oval (what does it do? nothing yet)
    ("pad", 2900, 40, 0), ("spikes", 2970, 120, 0),
    ("pad", 3164, 40, 0), ("spikes", 3234, 120, 0),
    ("pad", 3428, 40, 0), ("spikes", 3498, 120, 0),
    ("pad", 3692, 40, 0),
    ("pad", 4250, 40, 0), ("spikes", 4320, 120, 0),
    ("pad", 4514, 40, 0), ("spikes", 4584, 120, 0),
    ("pad", 4778, 40, 0),

    # Row 3: a pad up onto a long high path, then a pad over a spike row
    ("pad", 5250, 40, 0),
    ("block", 5370, 1130, 100),         # the long high path
    ("spikes", 5800, 40, 100),          # spikes on top of the path
    ("spikes", 6150, 80, 100),
    ("pad", 6700, 40, 0), ("spikes", 6770, 120, 0),
    ("spikes", 7200, 80, 0),            # tall spikes at the end of the row

    # Row 4: "777" makes everything fast, then a long empty run
    ("pad", 7500, 40, 0),
    ("portal_fast", 7620, 36, 0),

    # Row 5: "7" makes everything slow, then 8 jumps from pad to pad
    ("portal_slow", 9300, 36, 0),
    ("pad", 9500, 40, 0), ("spikes", 9560, 40, 0),
    ("pad", 9676, 40, 0), ("spikes", 9736, 40, 0),
    ("pad", 9852, 40, 0), ("spikes", 9912, 40, 0),
    ("pad", 10028, 40, 0), ("spikes", 10088, 40, 0),
    ("pad", 10204, 40, 0), ("spikes", 10264, 40, 0),
    ("pad", 10380, 40, 0), ("spikes", 10440, 40, 0),
    ("pad", 10556, 40, 0), ("spikes", 10616, 40, 0),
    ("pad", 10732, 40, 0),

    # Row 6: HOLD to keep jumping on a high path, drop down, jump the last spikes
    ("pad", 11100, 40, 0),
    ("block", 11180, 1220, 80),
    ("spikes", 11500, 40, 80),
    ("spikes", 11800, 40, 80),
    ("spikes", 12100, 40, 80),
    ("spikes", 12650, 40, 0),           # down at the bottom
    ("spikes", 12900, 40, 0),
    ("spikes", 13150, 40, 0),
]
LEVEL_1_LENGTH = 13500          # where the trophy (END) stands

# LEVEL 2, copied from the drawing assets/level-2.jpg (6 rows, read left to right, top to bottom).
# Same kinds of things as Level 1, plus:
#   "square"   - a floating block; how high = how high its bottom floats
#   "jump_orb" - a yellow ring; how high = how high its middle floats
#   "pit"      - a hole in the ground (jump over it!)
#   "fence"    - a fence you can stand on; how high = its height
#   "portal_fly" / "portal_run" - start and stop flying
LEVEL_2 = [
    # Row 1 (purple ground): jumps, then hop over a long spike row on floating squares
    ("spikes", 600, 40, 0),
    ("spikes", 1050, 80, 0),
    ("spikes", 1500, 600, 0),           # the long spike row...
    ("square", 1560, 100, 50),          # ...with squares to hop across
    ("square", 1770, 100, 50),
    ("square", 1980, 100, 50),
    ("spikes", 2450, 80, 0),

    # Row 2: a very long spike row; jump orbs (the little x's) carry you over
    ("spikes", 2900, 40, 0),
    ("spikes", 3200, 1000, 0),
    ("jump_orb", 3294, 50, 110),
    ("jump_orb", 3498, 50, 110),
    ("jump_orb", 3702, 50, 110),
    ("jump_orb", 3906, 50, 110),
    ("jump_orb", 4110, 50, 110),
    ("spikes", 4500, 80, 0),

    # Row 3: spikes, a tower to land on, more jump orbs (the dots), then down the slope
    ("spikes", 5000, 40, 0),
    ("spikes", 5250, 80, 0),
    ("spikes", 5500, 80, 0),
    ("spikes", 5750, 80, 0),            # spikes in front of the tower
    ("block", 5830, 60, 80),            # the tower
    ("spikes", 6300, 800, 0),
    ("jump_orb", 6394, 50, 110),
    ("jump_orb", 6598, 50, 110),
    ("jump_orb", 6802, 50, 110),
    ("jump_orb", 7006, 50, 110),        # the last one (the little circle)
    ("spikes", 7400, 80, 0),
    ("spikes", 7650, 80, 0),
    ("spikes", 7900, 80, 0),

    # Rows 4 and 5: the oval is a FLY portal! Fly along the wavy line between the blocks
    ("portal_fly", 8200, 36, 0),
    ("square", 8500, 50, 20), ("square", 8500, 50, 200),   # a gate: fly through the gap between the two squares
    ("square", 8800, 50, 90), ("square", 8800, 50, 270),
    ("square", 9100, 50, 40), ("square", 9100, 50, 220),
    ("square", 9400, 50, 80), ("square", 9400, 50, 260),
    ("square", 9700, 50, 0), ("square", 9700, 50, 180),
    ("square", 10000, 50, 60), ("square", 10000, 50, 240),
    ("square", 10300, 50, 90), ("square", 10300, 50, 270),
    ("square", 10600, 50, 30), ("square", 10600, 50, 210),
    ("square", 10900, 50, 0), ("square", 10900, 50, 180),
    ("square", 11200, 50, 70), ("square", 11200, 50, 250),
    ("square", 11500, 50, 90), ("square", 11500, 50, 270),
    ("square", 11800, 50, 40), ("square", 11800, 50, 220),
    ("square", 12100, 50, 10), ("square", 12100, 50, 190),

    # Row 6 (green ground): a RUN portal brings the hero back down, then spikes, a pit and a fence
    ("portal_run", 12500, 36, 0),
    ("spikes", 12900, 40, 0),
    ("spikes", 13300, 80, 0),
    ("spikes", 13700, 80, 0),
    ("spikes", 14100, 80, 0),
    ("spikes", 14500, 80, 0),
    ("pit", 14900, 140, 0),             # the deep pit: jump over it!
    ("fence", 15300, 120, 80),          # the fence: land on it...
    ("spikes", 15420, 120, 0),          # ...and jump over the spikes behind it
]
LEVEL_2_LENGTH = 15900          # where the trophy (END) stands

# All the drawn levels: their list, where the trophy stands, and the name shown in the corner
LEVELS = {
    "LEVEL_1": (LEVEL_1, LEVEL_1_LENGTH, "Level 1"),
    "LEVEL_2": (LEVEL_2, LEVEL_2_LENGTH, "Level 2"),
}

# Autopilot settings (the computer plays by itself; press A to switch it on or off)
AUTO_LEVELS = ["LEVEL_1"]       # where the autopilot works (add "RANDOM" to use it in the random run too)
AUTO_PLAY = True                # True = the autopilot is on when the game starts (press A to switch it off)
AUTO_JUMP_FRAMES = 1            # extra frames the autopilot jumps early (0-2 work, 3+ jumps too early and crashes)
DANGER_KINDS = ["spike", "low_wall", "tall_wall", "block"]   # things the autopilot jumps over
AUTO_THINK_FRAMES = 90          # how far into the future the autopilot imagines (60 frames = 1 second)
AUTO_COLOR = (40, 110, 220)     # color of the "AUTOPILOT" sign
auto_play = AUTO_PLAY

obstacles = []                  # each one: (what it is, its box on the screen)
spawn_timer = 0
next_spawn = SPAWN_MIN_FRAMES

# Orb settings (orbs are money for the shop)
ORB_CHANCE = 0.6                # how often an orb floats above an obstacle group (0 = never, 1 = always)
ORB_HEIGHT = 30                 # orb picture height
ORB_ABOVE_FLOOR = 140           # how high the orb floats, so you catch it by jumping
orbs = []                       # boxes of the orbs on the screen
orbs_collected = 0

# Make the pictures the right size for the game
hero_picture = pygame.transform.smoothscale_by(HERO_IMAGE, HERO_PICTURE_HEIGHT / HERO_IMAGE.get_height())
spike_picture = pygame.transform.smoothscale(SPIKE_IMAGE, (SPIKE_WIDTH, SPIKE_HEIGHT))
down_spike_picture = pygame.transform.flip(
    pygame.transform.smoothscale(SPIKE_IMAGE, (SPIKE_WIDTH, DOWN_SPIKE_HEIGHT)), False, True)
trophy_picture = pygame.transform.smoothscale_by(TROPHY_IMAGE, TROPHY_HEIGHT / TROPHY_IMAGE.get_height())
orb_picture = pygame.transform.smoothscale_by(ORB_IMAGE, ORB_HEIGHT / ORB_IMAGE.get_height())
win_picture = pygame.transform.smoothscale_by(WIN_IMAGE, WIN_PICTURE_HEIGHT / WIN_IMAGE.get_height())

# The background picture: paper color with soft marker lines on top
background_picture = pygame.Surface(BACKGROUND_IMAGE.get_size())
background_picture.fill(BG_COLOR)
BACKGROUND_IMAGE.set_alpha(BACKGROUND_STRENGTH)
background_picture.blit(BACKGROUND_IMAGE, (0, 0))

# Game States: "TITLE" (the first screen), "MENU", "PLAYING" or "WON"
game_state = "TITLE"
frame_count = 0                 # counts frames, for blinking
last_level = None               # the level played last time; SPACE in the menu plays it again

def build_level(level):
    # Turn the level list into boxes on the screen (most of them still far to the right)
    built = []
    for kind, start, width, high in level:
        x = player_x + start
        bottom = FLOOR_Y - high           # where its bottom sits
        if kind == "spikes":
            for spike_x in range(x, x + width, SPIKE_WIDTH):
                built.append(("spike", pygame.Rect(spike_x, bottom - SPIKE_HEIGHT, SPIKE_WIDTH, SPIKE_HEIGHT)))
        elif kind == "block":
            built.append(("block", pygame.Rect(x, bottom, width, high)))
        elif kind == "hanging":
            # a block from the top of the window down, with spikes pointing down under it
            built.append(("hanging", pygame.Rect(x, 0, width, bottom - DOWN_SPIKE_HEIGHT)))
            for spike_x in range(x, x + width, SPIKE_WIDTH):
                built.append(("spike_down", pygame.Rect(spike_x, bottom - DOWN_SPIKE_HEIGHT, SPIKE_WIDTH, DOWN_SPIKE_HEIGHT)))
        elif kind == "pad":
            built.append(("pad", pygame.Rect(x, bottom - PAD_HEIGHT, width, PAD_HEIGHT)))
        elif kind == "square":
            built.append(("square", pygame.Rect(x, bottom - SQUARE_HEIGHT, width, SQUARE_HEIGHT)))
        elif kind == "jump_orb":
            built.append(("jump_orb", pygame.Rect(x, bottom - width // 2, width, width)))
        elif kind == "pit":
            built.append(("pit", pygame.Rect(x, FLOOR_Y, width, SCREEN_HEIGHT - FLOOR_Y)))
        elif kind == "fence":
            built.append(("fence", pygame.Rect(x, bottom, width, high)))
        else:  # portals and the ring
            built.append((kind, pygame.Rect(x, bottom - PORTAL_HEIGHT, width, PORTAL_HEIGHT)))
    return built

def reset_game(mode):
    global player_y, velocity_y, is_grounded, angle, obstacles, spawn_timer, next_spawn
    global orbs, orbs_collected, level_mode, level_length, distance, speed, flying
    player_y = FLOOR_Y - player_size
    velocity_y = 0
    is_grounded = True
    angle = 0
    orbs = []
    orbs_collected = 0
    spawn_timer = 0
    next_spawn = SPAWN_MIN_FRAMES
    distance = 0
    speed = SPEED
    flying = False
    level_mode = mode
    if mode in LEVELS:
        level, level_length, name = LEVELS[mode]
        obstacles = build_level(level)
    else:
        obstacles = []
        level_length = LEVEL_SECONDS * FPS * SPEED

def add_obstacle_group():
    # Pick a random group and put it just past the right edge of the screen
    group_right = SCREEN_WIDTH
    for kind, offset in random.choice(OBSTACLE_PATTERNS):
        width, height = OBSTACLE_SIZES[kind]
        box = pygame.Rect(SCREEN_WIDTH + offset, FLOOR_Y - height, width, height)
        obstacles.append((kind, box))
        group_right = max(group_right, box.right)

    # Sometimes an orb floats above the group, to grab while jumping over it
    if random.random() < ORB_CHANCE:
        orb_box = orb_picture.get_rect(center=((SCREEN_WIDTH + group_right) // 2, FLOOR_Y - ORB_ABOVE_FLOOR))
        orbs.append(orb_box)

def frames_to_climb(height):
    # How many frames a jump needs to lift the hero's feet this high
    climbed = 0
    jump_speed = JUMP_STRENGTH
    frames = 0
    while climbed < height and jump_speed < 0:
        jump_speed += GRAVITY
        climbed -= jump_speed
        frames += 1
    return frames

def danger_is_close():
    # The autopilot's simple rule: look for the next danger: something sticking up higher than the hero's feet
    feet = player_y + player_size
    dangers = sorted((box for kind, box in obstacles
                      if kind in DANGER_KINDS and box.right > player_x and box.top < feet),
                     key=lambda box: box.left)
    if not dangers:
        return False

    # Dangers right next to each other are one big danger: aim for the tallest one
    target = dangers[0]
    group_right = target.right
    for box in dangers[1:]:
        if box.left > group_right + player_size:
            break  # the hero fits in this gap, so the next danger comes later
        group_right = max(group_right, box.right)
        if box.top < target.top:
            target = box

    # A jump pad comes first? Then let the pad throw the hero over
    for kind, box in obstacles:
        if kind == "pad" and box.right > player_x and box.left < target.left:
            return False

    # Jump just in time: when the hero would need exactly this long to climb over it
    gap = target.left - (player_x + player_size)
    return gap <= speed * (frames_to_climb(feet - target.top) + AUTO_JUMP_FRAMES)

def remember_game():
    # Take a "photo" of everything that moves, so we can put it back later
    return (game_state, player_y, velocity_y, is_grounded, angle, distance, speed, flying,
            [(kind, box.copy()) for kind, box in obstacles], spawn_timer, next_spawn,
            [orb_box.copy() for orb_box in orbs], orbs_collected, random.getstate())

def put_game_back(photo):
    # Put everything back exactly like in the "photo"
    global game_state, player_y, velocity_y, is_grounded, angle, distance, speed
    global obstacles, spawn_timer, next_spawn, orbs, orbs_collected, flying
    (game_state, player_y, velocity_y, is_grounded, angle, distance, speed, flying,
     obstacles, spawn_timer, next_spawn, orbs, orbs_collected, random_state) = photo
    obstacles = [(kind, box.copy()) for kind, box in obstacles]
    orbs = [orb_box.copy() for orb_box in orbs]
    random.setstate(random_state)

def can_survive(frames_left, dead_ends):
    # Play on "in the head": is there ANY way to jump that keeps the hero alive this long?
    # It tries the simple rule first, and the opposite only if the simple rule crashes.
    if game_state != "PLAYING" or frames_left == 0:
        return game_state != "MENU"   # "MENU" means it crashed
    if not is_grounded:
        update_game(False)            # in the air there is nothing to decide
        return can_survive(frames_left - 1, dead_ends)

    spot = (distance, round(player_y), round(velocity_y))
    if spot in dead_ends:
        return False                  # we already know: from here, every way crashes
    usual = danger_is_close()
    photo = remember_game()
    for jump in (usual, not usual):
        update_game(jump)
        if can_survive(frames_left - 1, dead_ends):
            return True
        put_game_back(photo)
    dead_ends.add(spot)
    return False

def autopilot_wants_jump():
    # Should the autopilot press jump right now? It imagines the future before deciding.
    if game_state != "PLAYING" or not is_grounded:
        return False                  # it can only jump when standing on something
    usual = danger_is_close()
    photo = remember_game()
    dead_ends = set()
    for jump in (usual, not usual):
        update_game(jump)
        survived = can_survive(AUTO_THINK_FRAMES, dead_ends)
        put_game_back(photo)
        if survived:
            return jump               # this way works (maybe it's a stepping-stone jump!)
    return usual                      # every way crashes: just do the usual thing

def update_game(holding):
    # One step of the game (60 times a second). holding = Space or a finger is down.
    global game_state, player_y, velocity_y, is_grounded, angle, distance, speed
    global obstacles, spawn_timer, next_spawn, orbs, orbs_collected, flying

    # Jump while Space or a finger is held down: keep holding and the hero jumps again every time it lands
    if game_state == "PLAYING" and holding and is_grounded and not flying:
        velocity_y = JUMP_STRENGTH
        is_grounded = False

    # Gravity keeps working after winning, so the hero lands at the finish
    if game_state == "PLAYING" or game_state == "WON":
        if flying:
            # Flying: holding pushes the hero up, letting go lets it sink (never too fast)
            velocity_y += -FLY_LIFT if holding else FLY_GRAVITY
            velocity_y = max(-FLY_MAX_SPEED, min(velocity_y, FLY_MAX_SPEED))
        else:
            velocity_y += GRAVITY
        player_y += velocity_y
        if flying and player_y < 0:
            player_y = 0                # the top of the sky: can't fly higher
            velocity_y = 0

        # Is there ground under the hero? Not if the middle of the hero is over a pit
        middle = player_x + player_size // 2
        over_pit = any(kind == "pit" and box.left < middle < box.right for kind, box in obstacles)
        feet_before = player_y + player_size - velocity_y
        if player_y >= FLOOR_Y - player_size and feet_before <= FLOOR_Y and not over_pit:
            player_y = FLOOR_Y - player_size
            velocity_y = 0
            is_grounded = True
            angle = round(angle / 90) * 90
        else:
            is_grounded = False  # in the air (a block below can still catch the hero, see below)

        if flying:
            angle = velocity_y * FLY_TILT  # nose up when going up, nose down when sinking
        elif not is_grounded:
            angle += 8

    # Only scroll, spawn and check crashes while actively playing
    if game_state != "PLAYING":
        return

    # Move forward; at the end of the level, the hero has won!
    distance += speed
    if distance >= level_length:
        distance = level_length
        game_state = "WON"

    # Random run: a new random group of obstacles now and then (but not right before the finish)
    if level_mode == "RANDOM":
        spawn_timer += 1
        if spawn_timer >= next_spawn and level_length - distance > QUIET_END_SECONDS * FPS * speed:
            add_obstacle_group()
            spawn_timer = 0
            next_spawn = random.randint(SPAWN_MIN_FRAMES, SPAWN_MAX_FRAMES)

    # Move obstacles to the left, forget the ones that left the screen
    for kind, box in obstacles:
        box.x -= speed
    obstacles = [(kind, box) for kind, box in obstacles if box.right > 0]
    for orb_box in orbs:
        orb_box.x -= speed

    # Land on top of blocks: if the hero was above the block's top a moment ago
    # and is falling onto it now, it stands on the block instead of crashing
    for kind, box in obstacles:
        if kind not in BLOCK_KINDS:
            continue  # you can never stand on a spike!
        bottom = player_y + player_size
        bottom_before = bottom - velocity_y
        above_block = player_x + player_size > box.left and player_x < box.right
        if above_block and velocity_y >= 0 and bottom_before <= box.top <= bottom:
            player_y = box.top - player_size
            velocity_y = 0
            is_grounded = True
            angle = round(angle / 90) * 90

    player_rect = pygame.Rect(player_x, player_y, player_size, player_size)
    for kind, box in obstacles:
        # Jump pads throw the hero up high
        if kind == "pad" and player_rect.colliderect(box) and velocity_y >= 0:
            velocity_y = PAD_STRENGTH
            is_grounded = False
        # Portals change the speed when the hero goes through them
        going_through = box.left < player_rect.right and box.right > player_rect.left
        if kind in PORTAL_SPEEDS and going_through:
            speed = PORTAL_SPEEDS[kind]
        # The FLY portal starts flying, the RUN portal stops it
        if kind == "portal_fly" and going_through:
            flying = True
        if kind == "portal_run" and going_through and flying:
            flying = False
            angle = 0

    # Jump orbs: press jump while touching one, and the hero jumps again in the air (each orb works once)
    if holding and not flying:
        for number, (kind, box) in enumerate(obstacles):
            if kind == "jump_orb" and player_rect.colliderect(box):
                velocity_y = JUMP_STRENGTH
                is_grounded = False
                obstacles[number] = ("used_orb", box)

    # Grab orbs the hero touches, forget the ones that left the screen
    for orb_box in orbs:
        if player_rect.colliderect(orb_box):
            orbs_collected += 1
    orbs = [orb_box for orb_box in orbs if not player_rect.colliderect(orb_box) and orb_box.right > 0]

    # Collision Check -> Send player back to menu on crash
    # (touching a spike, or running into the side of a block)
    for kind, box in obstacles:
        if kind not in HARMLESS_KINDS and player_rect.colliderect(box):
            game_state = "MENU"  # Return to menu on crash
    # Fell into a pit
    if player_y + player_size > FLOOR_Y + PIT_FALL_DEPTH:
        game_state = "MENU"

async def main():
    # The game loop lives in main() so it can also run in a web browser
    global game_state, auto_play, frame_count, last_level

    running = True
    while running:
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                running = False

            # A = switch the autopilot on or off (works in the menu and while playing)
            if event.type == pygame.KEYDOWN and event.key == pygame.K_a:
                auto_play = not auto_play

            # Title screen: click/tap PLAY (or press SPACE or Enter) to go to the menu
            if game_state == "TITLE":
                pressed_key = event.type == pygame.KEYDOWN and event.key in (pygame.K_SPACE, pygame.K_RETURN)
                clicked_play = event.type == pygame.MOUSEBUTTONDOWN and PLAY_BUTTON.collidepoint(event.pos)
                if pressed_key or clicked_play:
                    game_state = "MENU"
                continue  # nothing else happens on the title screen

            # Keyboard: Space/Enter = play the last level again (the very first time you have to pick one),
            # R = random run, 1 = Level 1, 2 = Level 2.
            # Tap or click: left third of the screen = random run, middle = Level 1, right = Level 2.
            pressed_space = event.type == pygame.KEYDOWN and event.key in (pygame.K_SPACE, pygame.K_RETURN)
            pick = None
            if pressed_space:
                pick = last_level
            if event.type == pygame.KEYDOWN and event.key == pygame.K_r:
                pick = "RANDOM"
            if event.type == pygame.KEYDOWN and event.key in (pygame.K_1, pygame.K_KP1):
                pick = "LEVEL_1"
            if event.type == pygame.KEYDOWN and event.key in (pygame.K_2, pygame.K_KP2):
                pick = "LEVEL_2"
            if event.type == pygame.MOUSEBUTTONDOWN:
                pick = ["RANDOM", "LEVEL_1", "LEVEL_2"][min(event.pos[0] * 3 // SCREEN_WIDTH, 2)]
            if game_state == "MENU" and pick:
                # Start the game from the menu, and remember this level for SPACE next time
                game_state = "PLAYING"
                reset_game(pick)
                last_level = pick

            elif game_state == "WON" and (pick or pressed_space):
                # Go back to the menu
                game_state = "MENU"

        # Update: everything moves one step
        holding = pygame.key.get_pressed()[pygame.K_SPACE] or pygame.mouse.get_pressed()[0]
        if auto_play and level_mode in AUTO_LEVELS and autopilot_wants_jump():
            holding = True    # the autopilot "presses Space" for you
        update_game(holding)

        # --- DRAWING SECTION ---
        screen.fill(BG_COLOR)

        frame_count += 1
        if game_state == "TITLE":
            # The title screen: the artist's drawing, with a blinking frame around PLAY
            screen.blit(START_IMAGE, (START_PICTURE_X, 0))
            if PLAY_BLINK_FRAMES and (frame_count // PLAY_BLINK_FRAMES) % 2 == 0:
                pygame.draw.rect(screen, PLAY_FRAME_COLOR, PLAY_BUTTON, 4, border_radius=8)

        elif game_state == "MENU":
            # Draw Start Menu UI: random run on the left, Level 1 in the middle, Level 2 on the right
            title_surf = font_title.render("GEOMETRY RUNNER", True, TITLE_COLOR)
            screen.blit(title_surf, (SCREEN_WIDTH // 2 - title_surf.get_width() // 2, 110))
            for line_x in (SCREEN_WIDTH // 3, SCREEN_WIDTH * 2 // 3):
                pygame.draw.line(screen, INK_COLOR, (line_x, 190), (line_x, 300), 2)
            choices = [("Random", "press R or tap here", SCREEN_WIDTH // 6),
                       ("Level 1", "press 1 or tap here", SCREEN_WIDTH // 2),
                       ("Level 2", "press 2 or tap here", SCREEN_WIDTH * 5 // 6)]
            for name, how, center_x in choices:
                name_surf = font_title.render(name, True, TEXT_COLOR)
                how_surf = font_instruction.render(how, True, TEXT_COLOR)
                screen.blit(name_surf, (center_x - name_surf.get_width() // 2, 200))
                screen.blit(how_surf, (center_x - how_surf.get_width() // 2, 260))
            # The autopilot switch sits under Level 1, because it only works there
            auto_text = "Autopilot: ON (press A)" if auto_play else "Autopilot: OFF (press A)"
            auto_surf = font_instruction.render(auto_text, True, AUTO_COLOR)
            screen.blit(auto_surf, (SCREEN_WIDTH // 2 - auto_surf.get_width() // 2, 310))
            # After playing once: SPACE plays the same level again
            if last_level:
                last_name = LEVELS[last_level][2] if last_level in LEVELS else "the random run"
                again_surf = font_instruction.render(f"SPACE = play {last_name} again", True, TEXT_COLOR)
                screen.blit(again_surf, (SCREEN_WIDTH // 2 - again_surf.get_width() // 2, 350))

        elif game_state == "WON":
            # The winning screen: the "Level complete" drawing in the middle
            screen.blit(win_picture, (SCREEN_WIDTH // 2 - win_picture.get_width() // 2, WIN_PICTURE_TOP))
            again_surf = font_instruction.render("Press SPACE or tap the screen for the menu", True, TEXT_COLOR)
            again_y = WIN_PICTURE_TOP + win_picture.get_height() + 12
            screen.blit(again_surf, (SCREEN_WIDTH // 2 - again_surf.get_width() // 2, again_y))

        elif game_state == "PLAYING":
            # Draw the background: copies side by side, sliding left slower than the obstacles
            background_width = background_picture.get_width()
            background_x = -int(distance * BACKGROUND_SCROLL) % background_width
            for x in range(background_x - background_width, SCREEN_WIDTH, background_width):
                screen.blit(background_picture, (x, 0))

            # Draw Obstacles (spikes, blocks, pads, portals) that are on the screen
            for kind, box in obstacles:
                if box.left > SCREEN_WIDTH:
                    continue
                if kind == "spike":
                    screen.blit(spike_picture, box.topleft)
                elif kind == "spike_down":
                    screen.blit(down_spike_picture, box.topleft)
                elif kind == "pad":
                    # a yellow bump: the top half of an oval
                    screen.set_clip(box)
                    pygame.draw.ellipse(screen, PAD_COLOR, (box.x, box.y, box.width, box.height * 2))
                    pygame.draw.ellipse(screen, INK_COLOR, (box.x, box.y, box.width, box.height * 2), 3)
                    screen.set_clip(None)
                elif kind == "jump_orb":
                    pygame.draw.circle(screen, JUMP_ORB_COLOR, box.center, box.width // 2 - 4)
                    pygame.draw.circle(screen, INK_COLOR, box.center, box.width // 2 - 4, 3)
                elif kind == "used_orb":
                    pygame.draw.circle(screen, JUMP_ORB_COLOR, box.center, box.width // 2 - 4, 3)
                elif kind == "pit":
                    continue  # drawn after the floor, as a hole in it
                elif kind == "fence":
                    # bars and rails, like the grid in the drawing
                    for bar_x in range(box.left, box.right + 1, FENCE_GAP):
                        pygame.draw.line(screen, INK_COLOR, (bar_x, box.top), (bar_x, box.bottom), 3)
                    for rail_y in range(box.top, box.bottom + 1, FENCE_GAP):
                        pygame.draw.line(screen, INK_COLOR, (box.left, rail_y), (box.right, rail_y), 3)
                elif kind in PORTAL_COLORS:
                    pygame.draw.ellipse(screen, PORTAL_COLORS[kind], box, 6)
                    label_surf = font_instruction.render(PORTAL_LABELS[kind], True, PORTAL_COLORS[kind])
                    screen.blit(label_surf, (box.centerx - label_surf.get_width() // 2, box.top - 28))
                else:
                    pygame.draw.rect(screen, WALL_COLOR, box)
                    pygame.draw.rect(screen, INK_COLOR, box, 3)

            # Draw Floor
            pygame.draw.rect(screen, FLOOR_COLOR, (0, FLOOR_Y, SCREEN_WIDTH, SCREEN_HEIGHT - FLOOR_Y))
            for kind, box in obstacles:
                if kind == "pit" and box.left < SCREEN_WIDTH:
                    pygame.draw.rect(screen, PIT_COLOR, box)

            # Draw Orbs
            for orb_box in orbs:
                screen.blit(orb_picture, orb_box.topleft)

            # Draw the trophy at the finish: it scrolls in and stops right in front of the hero
            finish_x = player_x + player_size + TROPHY_GAP + (level_length - distance)
            if finish_x < SCREEN_WIDTH:
                screen.blit(trophy_picture, (finish_x, FLOOR_Y - TROPHY_HEIGHT))

            # Draw the orb counter in the top left corner
            screen.blit(orb_picture, (16, 12))
            orbs_surf = font_instruction.render(str(orbs_collected), True, TEXT_COLOR)
            screen.blit(orbs_surf, (16 + orb_picture.get_width() + 8, 14))

            # Top right corner: the countdown (random run) or how far you got (drawn levels)
            if level_mode == "RANDOM":
                frames_left = (level_length - distance) // speed
                seconds_left = (frames_left + FPS - 1) // FPS
                corner_text = f"{seconds_left // 60}:{seconds_left % 60:02d}"
            else:
                corner_text = f"{LEVELS[level_mode][2]}   {distance * 100 // level_length}%"
            corner_surf = font_instruction.render(corner_text, True, TEXT_COLOR)
            screen.blit(corner_surf, (SCREEN_WIDTH - corner_surf.get_width() - 16, 12))

            # A sign at the top in the middle while the computer is playing
            if auto_play and level_mode in AUTO_LEVELS:
                auto_surf = font_instruction.render("AUTOPILOT", True, AUTO_COLOR)
                screen.blit(auto_surf, (SCREEN_WIDTH // 2 - auto_surf.get_width() // 2, 12))

            # Draw Player
            rotated_surface = pygame.transform.rotate(hero_picture, -angle)
            new_rect = rotated_surface.get_rect(center=(player_x + player_size // 2, player_y + player_size // 2))
            screen.blit(rotated_surface, new_rect.topleft)

        pygame.display.flip()
        clock.tick(FPS)
        await asyncio.sleep(0)  # let the browser update the page (does nothing on the computer)

    pygame.quit()

asyncio.run(main())
