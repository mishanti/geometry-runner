import asyncio
import random
import pygame

pygame.init()
pygame.font.init()

SCREEN_WIDTH = 800
SCREEN_HEIGHT = 400
FPS = 60

# Colors (RGB)
BG_COLOR = (235, 230, 215)      # paper color, like the drawings
FLOOR_COLOR = (50, 180, 80)
TITLE_COLOR = (215, 30, 40)     # red, like the hero
TEXT_COLOR = (30, 30, 40)
INK_COLOR = (15, 15, 20)        # black pen, like the drawings
WALL_COLOR = (90, 90, 100)      # inside of the barriers

screen = pygame.display.set_mode((SCREEN_WIDTH, SCREEN_HEIGHT))
pygame.display.set_caption("My First Geometry Runner")
clock = pygame.time.Clock()

# Pictures drawn by hand (made from the drawings by tools/make_sprites.py)
HERO_IMAGE = pygame.image.load("assets/square-hero-sprite.png").convert_alpha()
SPIKE_IMAGE = pygame.image.load("assets/spike-sprite.png").convert_alpha()
TROPHY_IMAGE = pygame.image.load("assets/trophy-sprite.png").convert_alpha()
ORB_IMAGE = pygame.image.load("assets/orb-sprite.png").convert_alpha()

# Fonts for UI text
font_title = pygame.font.SysFont("Arial", 44, bold=True)
font_instruction = pygame.font.SysFont("Arial", 22)

FLOOR_Y = 320

# Player settings
player_size = 50
HERO_PICTURE_HEIGHT = 100  # the drawing is bigger than the player: spikes stick out around the red box
player_x = 100
player_y = FLOOR_Y - player_size

velocity_y = 0
GRAVITY = 0.8
JUMP_STRENGTH = -14
is_grounded = True
angle = 0

# Level settings
LEVEL_SECONDS = 30              # how long a level lasts (in seconds)
QUIET_END_SECONDS = 3           # no new obstacles at the very end, so the way to the finish is clear
TROPHY_HEIGHT = 90             # the trophy waits at the finish (official levels only)
TROPHY_GAP = 30                 # space between the hero and the trophy at the end, so the spikes don't cover it
frames_left = LEVEL_SECONDS * FPS

# Obstacle settings
SPEED = 6
SPIKE_WIDTH = 40
SPIKE_HEIGHT = 50
LOW_WALL_WIDTH = 90             # a long, flat barrier
LOW_WALL_HEIGHT = 40
TALL_WALL_WIDTH = 40            # a thin, tall barrier
TALL_WALL_HEIGHT = 65
SPAWN_MIN_FRAMES = 60           # shortest wait before the next obstacle group
SPAWN_MAX_FRAMES = 110          # longest wait before the next obstacle group

# Groups of obstacles the game picks from at random.
# Each piece: (what it is, how far to the right of the group's start)
OBSTACLE_PATTERNS = [
    [("spike", 0)],
    [("spike", 0), ("spike", SPIKE_WIDTH)],
    [("low_wall", 0)],
    [("tall_wall", 0)],
]
OBSTACLE_SIZES = {
    "spike": (SPIKE_WIDTH, SPIKE_HEIGHT),
    "low_wall": (LOW_WALL_WIDTH, LOW_WALL_HEIGHT),
    "tall_wall": (TALL_WALL_WIDTH, TALL_WALL_HEIGHT),
}

obstacles = []                  # each one: (what it is, its box on the screen)
spawn_timer = 0
next_spawn = SPAWN_MIN_FRAMES

# Orb settings (orbs are money for the shop)
ORB_CHANCE = 0.6                # how often an orb floats above an obstacle group (0 = never, 1 = always)
ORB_HEIGHT = 30                 # orb picture height
ORB_ABOVE_FLOOR = 140           # how high the orb floats, so you catch it by jumping
orbs = []                       # boxes of the orbs on the screen
orbs_collected = 0

# Make the pictures the right size for the game
hero_picture = pygame.transform.smoothscale_by(HERO_IMAGE, HERO_PICTURE_HEIGHT / HERO_IMAGE.get_height())
spike_picture = pygame.transform.smoothscale(SPIKE_IMAGE, (SPIKE_WIDTH, SPIKE_HEIGHT))
trophy_picture = pygame.transform.smoothscale_by(TROPHY_IMAGE, TROPHY_HEIGHT / TROPHY_IMAGE.get_height())
orb_picture = pygame.transform.smoothscale_by(ORB_IMAGE, ORB_HEIGHT / ORB_IMAGE.get_height())

# Game States: "MENU", "PLAYING" or "WON"
game_state = "MENU"

def reset_game():
    global player_y, velocity_y, is_grounded, angle, obstacles, spawn_timer, next_spawn, frames_left
    global orbs, orbs_collected
    player_y = FLOOR_Y - player_size
    velocity_y = 0
    is_grounded = True
    angle = 0
    obstacles = []
    orbs = []
    orbs_collected = 0
    spawn_timer = 0
    next_spawn = SPAWN_MIN_FRAMES
    frames_left = LEVEL_SECONDS * FPS

def add_obstacle_group():
    # Pick a random group and put it just past the right edge of the screen
    group_right = SCREEN_WIDTH
    for kind, offset in random.choice(OBSTACLE_PATTERNS):
        width, height = OBSTACLE_SIZES[kind]
        box = pygame.Rect(SCREEN_WIDTH + offset, FLOOR_Y - height, width, height)
        obstacles.append((kind, box))
        group_right = max(group_right, box.right)

    # Sometimes an orb floats above the group, to grab while jumping over it
    if random.random() < ORB_CHANCE:
        orb_box = orb_picture.get_rect(center=((SCREEN_WIDTH + group_right) // 2, FLOOR_Y - ORB_ABOVE_FLOOR))
        orbs.append(orb_box)

async def main():
    # The game loop lives in main() so it can also run in a web browser
    global game_state, player_y, velocity_y, is_grounded, angle, frames_left
    global obstacles, spawn_timer, next_spawn, orbs, orbs_collected

    running = True
    while running:
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                running = False

            # "Go" means: Space or Enter on the keyboard, or a tap on the screen (or a mouse click)
            key_go = event.type == pygame.KEYDOWN and (event.key == pygame.K_SPACE or event.key == pygame.K_RETURN)
            tap_go = event.type == pygame.MOUSEBUTTONDOWN
            if key_go or tap_go:
                if game_state == "MENU":
                    # Start the game from the menu
                    game_state = "PLAYING"
                    reset_game()

                elif game_state == "WON":
                    # Go back to the menu
                    game_state = "MENU"

        # Jump while Space or a finger is held down: keep holding and the hero jumps again every time it lands
        holding = pygame.key.get_pressed()[pygame.K_SPACE] or pygame.mouse.get_pressed()[0]
        if game_state == "PLAYING" and holding and is_grounded:
            velocity_y = JUMP_STRENGTH
            is_grounded = False

        # Gravity keeps working after winning, so the hero lands at the finish
        if game_state == "PLAYING" or game_state == "WON":
            velocity_y += GRAVITY
            player_y += velocity_y

            if player_y >= FLOOR_Y - player_size:
                player_y = FLOOR_Y - player_size
                velocity_y = 0
                is_grounded = True
                angle = round(angle / 90) * 90
            else:
                is_grounded = False  # in the air (a block below can still catch the hero, see below)

            if not is_grounded:
                angle += 8

        # Only scroll, spawn and check crashes while actively playing
        if game_state == "PLAYING":
            # The countdown: one frame less every frame
            frames_left -= 1
            if frames_left <= 0:
                frames_left = 0
                game_state = "WON"  # Made it to the end of the level!

            # Spawn a new random group of obstacles (but not right before the finish)
            spawn_timer += 1
            if spawn_timer >= next_spawn and frames_left > QUIET_END_SECONDS * FPS:
                add_obstacle_group()
                spawn_timer = 0
                next_spawn = random.randint(SPAWN_MIN_FRAMES, SPAWN_MAX_FRAMES)

            # Move obstacles to the left, forget the ones that left the screen
            for kind, box in obstacles:
                box.x -= SPEED
            obstacles = [(kind, box) for kind, box in obstacles if box.right > 0]
            for orb_box in orbs:
                orb_box.x -= SPEED

            # Land on top of blocks: if the hero was above the block's top a moment ago
            # and is falling onto it now, it stands on the block instead of crashing
            for kind, box in obstacles:
                if kind == "spike":
                    continue  # you can never stand on a spike!
                bottom = player_y + player_size
                bottom_before = bottom - velocity_y
                above_block = player_x + player_size > box.left and player_x < box.right
                if above_block and velocity_y >= 0 and bottom_before <= box.top <= bottom:
                    player_y = box.top - player_size
                    velocity_y = 0
                    is_grounded = True
                    angle = round(angle / 90) * 90

            # Grab orbs the hero touches, forget the ones that left the screen
            player_rect = pygame.Rect(player_x, player_y, player_size, player_size)
            for orb_box in orbs:
                if player_rect.colliderect(orb_box):
                    orbs_collected += 1
            orbs = [orb_box for orb_box in orbs if not player_rect.colliderect(orb_box) and orb_box.right > 0]

            # Collision Check -> Send player back to menu on crash
            # (touching a spike, or running into the side of a block)
            for kind, box in obstacles:
                if player_rect.colliderect(box):
                    game_state = "MENU"  # Return to menu on crash

        # --- DRAWING SECTION ---
        screen.fill(BG_COLOR)

        if game_state == "MENU":
            # Draw Start Menu UI
            title_surf = font_title.render("GEOMETRY RUNNER", True, TITLE_COLOR)
            prompt_surf = font_instruction.render("Press SPACE or tap the screen to Play", True, TEXT_COLOR)

            # Center the text dynamically on screen
            screen.blit(title_surf, (SCREEN_WIDTH // 2 - title_surf.get_width() // 2, 130))
            screen.blit(prompt_surf, (SCREEN_WIDTH // 2 - prompt_surf.get_width() // 2, 210))

        elif game_state == "PLAYING" or game_state == "WON":
            # Draw Floor
            pygame.draw.rect(screen, FLOOR_COLOR, (0, FLOOR_Y, SCREEN_WIDTH, SCREEN_HEIGHT - FLOOR_Y))

            # Draw Obstacles (spikes and barriers)
            for kind, box in obstacles:
                if kind == "spike":
                    screen.blit(spike_picture, box.topleft)
                else:
                    pygame.draw.rect(screen, WALL_COLOR, box)
                    pygame.draw.rect(screen, INK_COLOR, box, 3)

            # Draw Orbs
            for orb_box in orbs:
                screen.blit(orb_picture, orb_box.topleft)

            # Draw the trophy at the finish: it scrolls in so it reaches the hero exactly when time runs out
            finish_x = player_x + player_size + TROPHY_GAP + frames_left * SPEED
            if finish_x < SCREEN_WIDTH:
                screen.blit(trophy_picture, (finish_x, FLOOR_Y - TROPHY_HEIGHT))

            # Draw the orb counter in the top left corner
            screen.blit(orb_picture, (16, 12))
            orbs_surf = font_instruction.render(str(orbs_collected), True, TEXT_COLOR)
            screen.blit(orbs_surf, (16 + orb_picture.get_width() + 8, 14))

            # Draw the countdown in the top right corner, like 3:59
            seconds_left = (frames_left + FPS - 1) // FPS
            timer_surf = font_instruction.render(f"{seconds_left // 60}:{seconds_left % 60:02d}", True, TEXT_COLOR)
            screen.blit(timer_surf, (SCREEN_WIDTH - timer_surf.get_width() - 16, 12))

            # Draw Player
            rotated_surface = pygame.transform.rotate(hero_picture, -angle)
            new_rect = rotated_surface.get_rect(center=(player_x + player_size // 2, player_y + player_size // 2))
            screen.blit(rotated_surface, new_rect.topleft)

            # Winning message
            if game_state == "WON":
                win_surf = font_title.render("YOU WIN!", True, TITLE_COLOR)
                again_surf = font_instruction.render("Press SPACE or tap the screen for the menu", True, TEXT_COLOR)
                screen.blit(win_surf, (SCREEN_WIDTH // 2 - win_surf.get_width() // 2, 110))
                screen.blit(again_surf, (SCREEN_WIDTH // 2 - again_surf.get_width() // 2, 170))

        pygame.display.flip()
        clock.tick(FPS)
        await asyncio.sleep(0)  # let the browser update the page (does nothing on the computer)

    pygame.quit()

asyncio.run(main())